/*
**   OPT7.e  - Extended Powell Singular Function
**             More, Garbow and Hillstrom, 1981, "Testing Unconstrained
**             Optimization Software", TOMS 7, 17-41.
**                          or
**             J.E. Dennis and R. B. Schnabel,
**             _Numerical Methods for Unconstrained Optimization and
**             Nonlinear Equations_, EngleWood Cliffs, NJ: Prentice Hall,
**             page 362.
*/
new;

library optmum;

//  Can be any value - 4*global_n coefficients will be estimated
global_n = 2;   

// Objective function
proc (1) = fct(x);
    local i, j, f, nparams;
    
    nparams = global_n * 4;
    
    f = zeros(nparams,1);
    
    for i(1, nparams, 4);        
      f[i] = x[i] + 10*x[i+1];
      f[i+1] = sqrt(5) * (x[i+2] - x[i+3]);
      f[i+2] = (x[i+1] - 2*x[i+2])^2;
      f[i+3] = sqrt(10) * (x[i] - x[i+3])^2;
    endfor;
    
    retp(f'f);
endp;

// Send all printed output to the file 'opt7.out'
// in your current working directory
output file = opt7.out reset;

// Set all global control variables
// to default settings
optset();

// Starting values
x00 = { 3, -1, 0, 1};
x0 = vec(x00 .*. ones(global_n,1));

__title = "Extended Powell Singular Function";

_opgtol = 1e-8;
_opstmth = "newton brent";

// Perform estimation and print output
call optprt(optmum(&fct,x0));

output off;

