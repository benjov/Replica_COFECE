/*
**   OPT2.E
**
**   This command file illustrates nonlinear least squares
**   estimation using OPTMUM.  The data for this example
**   have been created using NLIN.SIM.
*/
new;
library optmum;

// Reset global control variables to default settings
optset();

// Load data from dataset
nldat = loadd("nlin.dat");

// Objective function
proc fct(b);
    retp(b[1]+b[2]*exp(-b[3]*nldat[.,2]));
endp;

// Procedure to compute sum of squared deviations
proc ssq(b);
    local dev;
    dev = nldat[.,1] - fct(b);
    retp(dev'*dev);
endp;

// Send all printed output to the file
// opt2.out in your current working directory
output file = opt2.out reset;

startv = { .8, 1.2, .2 };
_opgtol = 1e-5;

// Perform estimation
{ bh,fmin,g,retcode } = optmum(&ssq,startv);

// Print report
call optprt(bh,fmin,g,retcode);

grd = gradp(&fct,bh);
cov = (fmin/rows(nldat))*invpd(grd'*grd);

print cov;
print;
print "standard errors of parameters";
sd = sqrt(diag(cov));
print sd';

print;
print "t-statistics";
print (bh./sd)';

output off;
