new;
library optmum;

// Reset global control variables to default settings
optset();

// Objective procedure
proc fct(x);
   local y1,y2;
    
   y1 = x[2] - x[1]*x[1];
   y2 = 1 - x[1];
    
   retp(1e2*y1*y1 + y2*y2);
endp;

_opstmth = "NEWTON BRENT";
__output = 1;

// Starting values
start = { -1, 1 };

output file = opt5.out reset;

// Perform estimation and print report
{ x,fmin,g,retcode } = optprt(optmum(&fct,start));

output off;

