/*
**   OPT3.E  -  Woods Function
**
*/
new;
library optmum;

// Reset global control variables to default settings
optset();

// Set up global variable used
// to initialize Hessian
h0 = zeros(4,4);
h0[4,2] = 19.8;
h0[4,4] = 200.2;
h0[2,4] = 19.8;
h0[2,2] = 220.2;

// Objective procedure
proc lpr(x);
    retp(100*(x[2]-x[1]^2)^2 + (1-x[1])^2 + 90*(x[4]-x[3]^2)^2 +
    (1-x[3])^2 + 10.1*((x[2]-1)^2 + (x[4]-1)^2) + 19.8*(x[2]-1)*(x[4]-1));
endp;

// Procedure to compute gradient
proc grd0(x);
    local a,b,g;
    a = x[2] - x[1]^2;
    b = x[4] - x[3]^2;
    g = zeros(1,4);
    g[1] = -2*(200*x[1]*a + 1 - x[1]);
    g[2] = 2*(100*a + 10.1*(x[2]-1) + 9.9*(x[4]-1));
    g[3] = -2*(180*x[3]*b + 1 - x[3]);
    g[4] = 2*(90*b + 10.1*(x[4]-1) + 9.9*(x[2]-1));
    retp(g);
endp;

// Procedure to compute Hessian
proc hss0(x);
    local h;
    
    // Initialize 'h' from global variable
    h = h0;
    
    h[1,1] = -2*(200*(x[2]-x[1]^2) - 400*x[1]^2 - 1);
    h[1,2] = -400*x[1];
    h[2,1] = h[1,2];
    h[3,3] = -2*(180*(x[4]-x[3]^2) - 360*x[3]^2 - 1);
    h[4,3] = -360*x[3];
    h[3,4] = h[4,3];
    
    retp(h);
endp;


// Starting values
x0 = { -3, -1, -3, -1 };


// Assign pointers to the procedures that
// compute the gradient and Hessian
_opgdprc = &grd0;
_ophsprc = &hss0;

_opmdmth = "newton brent";
_opditer = 10;

__title = "Wood's Problem";

// Send all printed output to the file
// opt3.out in your current working directory
output file = opt3.out reset;

// Perform estimation and print report
call optprt(optmum(&lpr,x0));

output off;
